package com.example.twiniot;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class Dashboard extends AppCompatActivity {
    NavigationView nav;
    DrawerLayout dra;
    Toolbar tool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
       tool=findViewById(R.id.toolbar);
        setSupportActionBar(tool);
        nav=findViewById(R.id.nevi);
        dra=findViewById(R.id.Drawer);
       ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,dra,tool,R.string.open,R.string.close);
        dra.addDrawerListener(toggle);
        toggle.syncState();
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.Location:
                        Toast.makeText(getApplication(), "location is open", Toast.LENGTH_SHORT).show();
                        dra.closeDrawer(GravityCompat.START );
                        break;
                    case R.id.Settings:
                        Toast.makeText(getApplication(), "settings is open", Toast.LENGTH_SHORT).show();
                        dra.closeDrawer(GravityCompat.START );
                        break;
                    case R.id.help:
                        Toast.makeText(getApplication(), "help is open", Toast.LENGTH_SHORT).show();
                        dra.closeDrawer(GravityCompat.START );
                        break;
                    case R.id.feedback:
                        Toast.makeText(getApplication(), "feedback is open", Toast.LENGTH_SHORT).show();
                        dra.closeDrawer(GravityCompat.START );
                        break;
                    default:

                }
                return true;

            }
        });
    }
}